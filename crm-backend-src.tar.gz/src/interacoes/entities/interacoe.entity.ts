export class Interacoe {}
