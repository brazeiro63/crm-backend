export class Contrato {}
