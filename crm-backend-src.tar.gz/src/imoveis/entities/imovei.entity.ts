export class Imovei {}
