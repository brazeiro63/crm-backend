Failed to load config file "/home/brazeiro63/crm-backend" as a TypeScript/JavaScript module. Error: PrismaConfigEnvError: Missing required environment variable: DATABASE_URL
